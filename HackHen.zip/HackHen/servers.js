

document.addEventListener('DOMContentLoaded', function() {
    const log = document.getElementById('log');
    const button = document.getElementById('hackButton');

    function addLog(message) {
        const entry = document.createElement('div');
        entry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        log.appendChild(entry);
        log.scrollTop = log.scrollHeight;
    }

    button.addEventListener('click', function() {
        addLog('Активация взлома Android...');
        
        setTimeout(() => addLog('Шаг 1: Установка соединения с устройством...'), 500);
        setTimeout(() => addLog('Шаг 2: Поиск уязвимостей в ядре...'), 1000);
        setTimeout(() => addLog('Шаг 3: Загрузка эксплойта...'), 1500);
        setTimeout(() => addLog('Шаг 4: Выполнение шелл-кода...'), 2000);
        setTimeout(() => addLog('Шаг 5: Получение root-прав...'), 2500);
        setTimeout(() => addLog('Взлом успешно активирован (active).'), 3000);
        
        button.disabled = true;
        button.textContent = 'Активировано';
        button.style.backgroundColor = 'red';
        button.style.color = 'white';
    });
});